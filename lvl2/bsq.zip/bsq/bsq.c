#include "bsq.h"

// handle stdin input
void	ft_bsq_from_stdin(FILE *stream)
{
	
}

//fopen(const char *pathname, const char *mode);
void	ft_bsq(char **argv)
{
	// FILE *file = fopen(stdin, "r");
		// if (!file)
		// 	return (1);
	//	check file that all lines are same length

	//	at least one line present with at least one box

	//	at end of line(EOL), line break!

	//	characters on the map can only be those introduced in the first line.

	//	map invalid when a char is missing from first line or two similar empty, full, obstacle char present

	//	The characters can be any printable character, even numbers.

	//	if invalid map, display "map error" at errno + line break -> next map
}
